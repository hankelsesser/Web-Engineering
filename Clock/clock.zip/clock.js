

function setTime () {
let  now = new Date ();
let birthday = new Date('May 13, 2020')

let count = birthday.getTime() - now.getTime();
let days = Math.floor(count / (1000 * 60 * 60 * 24));
let hours = Math.floor((count % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
let minutes = Math.floor((count % (1000 * 60 * 60)) / (1000 * 60));
let seconds = Math.floor((count % (1000 * 60)) / 1000);
// let days = count / 86400000;
// let hours = Math.round( );
// let min = Math.round(secs/60);

// let mili = birthday.getTime() - now.getTime();


document.getElementById("time").innerHTML = days + ":" + hours + ":" + minutes + ":" + seconds;

}



//document.getElementById("timedate").innerHTML = now.Date();

//module
//mod
setInterval(setTime, 1000);